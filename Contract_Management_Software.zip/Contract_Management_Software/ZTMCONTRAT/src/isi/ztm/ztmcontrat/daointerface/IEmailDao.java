package isi.ztm.ztmcontrat.daointerface;

public interface IEmailDao {
	public void sendEmail(String receiver, String object);
}

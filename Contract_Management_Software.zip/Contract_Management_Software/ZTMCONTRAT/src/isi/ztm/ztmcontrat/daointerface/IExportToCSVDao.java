package isi.ztm.ztmcontrat.daointerface;

public interface IExportToCSVDao {
public void WriteDataToCSVFile ();

}

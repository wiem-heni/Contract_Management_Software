package isi.ztm.ztmcontrat.daointerface;

import isi.ztm.ztmcontrat.entite.Duree;

public interface IDureeDao {
	public void ajouterDuree(Duree c);
	public void modifierDuree(Duree c);
}

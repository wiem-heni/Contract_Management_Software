package isi.ztm.ztmcontrat.serviceinterface;

public interface IEmailService {
	public void sendEmail(String receiver, String object);
}

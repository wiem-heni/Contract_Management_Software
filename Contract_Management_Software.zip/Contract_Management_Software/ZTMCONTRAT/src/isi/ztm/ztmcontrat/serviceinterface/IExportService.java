package isi.ztm.ztmcontrat.serviceinterface;

public interface IExportService {
	public void WriteDataToCSVFile ();
}

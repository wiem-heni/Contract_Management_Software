package isi.ztm.ztmcontrat.serviceinterface;

import isi.ztm.ztmcontrat.entite.Duree;

public interface IDureeService {
	public void ajouterDuree(Duree c);
	public void modifierDuree(Duree c);
}

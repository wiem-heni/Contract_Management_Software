/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package bdconnection;

/**
 *
 * @author Fray
 */
public class BdConst {

     public static final String DRIVER_NAME = "com.mysql.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://localhost:3306/tamkeen";
    public static final String DB_USER_NAME = "root";
    public static final String DB_PASSWORD = "root";

}
